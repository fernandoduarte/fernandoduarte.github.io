clear

date_begin = datenum(1962,7,1);                 % beginning of data used
date_end = datenum(2014,12,31);                 % end of data used
                 
addpath(genpath('kevinsheppard-mfe_toolbox-a93d075a449e'))

%% import FF factors
filename = 'ff_factors_and_momentum.csv'; 
fid = fopen(filename); % open files
headers = textscan(fgetl(fid),'%s','Delimiter',',');
ncols = size(headers{1},1);
data = textscan(fid,repmat('%f ',1,ncols),'Delimiter',',','EmptyValue',NaN);
fclose(fid);

% create matlab dates
date = datenum(num2str(data{1}),'yyyymm');
data(1)=[];
headers{1}(1)=[];

% put together in a struct
ff_ts.dates = date;
for i=1:size(data,2)
    ff_ts.(headers{1}{i})=data{i};
end

%% import CPI

filename = 'CPIAUCSL_2.xls'; 
[cpi_num, cpi_txt, cpi_raw] = xlsread(filename,'Vintages Starting 2015-02-20');
headers=cpi_txt(1,2:end);
keep =ismember(headers,'CPIAUCSL_20150220'); % select which CPI to use 

% create matlab dates -- unix gives dates as excel dates, windows as
% strings (haven't checked mac osx)
if isunix
    date = cpi_num(:,1)+datenum('30-Dec-1899');
    cpi = cpi_num(:,find(keep)+1);
else
    date = datenum(cpi_txt(2:end,1),'mm/dd/yyyy');
    cpi = cpi_num(:,keep);
end
inf = 100*(cpi(2:end)./cpi(1:end-1)-1);

% put together in a struct
inf_ts.dates = date;
inf_ts.cpi = cpi;
inf_ts.inf = [nan;inf];

%% create ARMA(1,1) inflation shocks

missing_inf_mat = isnan(inf_ts.inf);
inf_mat = inf_ts.inf(~missing_inf_mat);

% use Kevin Sheppard's toolbox
[parameters_arma_inf,~,u]=armaxfilter(inf_mat,1,1,1);

inf_ts.u = nan(size(inf_ts.inf));
inf_ts.u(~missing_inf_mat) = u/100;


%% import PCE

% files to read
bea_tables = {'Table 2.8.4. Price Indexes for Personal Consumption Expenditures by Major Type of Product, Monthly.csv',...
    'Table 2.8.5. Personal Consumption Expenditures by Major Type of Product, Monthly.csv'};

% loop through files
pce_ts = cell(length(bea_tables),1);
for i = 1:length(bea_tables)
    
    % open file
    filename = bea_tables{i};
    fid = fopen(filename);
    
    % read lines until data begins
    while isempty(strfind(fgetl(fid),'Last Revised'))
        % do nothing
    end
    
    % get data
    year_txt = textscan(fgetl(fid),'%s','Delimiter',',');
    month_txt = textscan(fgetl(fid),'%s','Delimiter',',');
    ncols = size(year_txt{1},1);
    data = textscan(fid,['%s' '%s' repmat('%f ',1,ncols-2)],'Delimiter',',','EmptyValue',NaN,'TreatAsEmpty','---');
    fclose(fid);
    
    % get names of variables and transform into nice matlab names
    headers = data{1,2}';
    headers_alphanum=isstrprop(headers,'alphanum');
    for headers_no=1:size(headers,2)
        headers{headers_no}(~headers_alphanum{headers_no})='';
        if isempty(headers{headers_no})
            headers{headers_no} = ['blank' num2str(headers_no)];
        end
    end
    
    month_txt = cellstr(vertcat(month_txt{1}{3:end}));
    year_txt = cellstr(vertcat(year_txt{1}{3:end}));
    date = datenum(cell2mat([year_txt month_txt]),'yyyymmm');
    
    % put together in a struct
    data_mat = cell2mat(data(1,3:end))';
    pce_ts{i}.dates = date;
    pce_ts{i}.desc = filename;
    for j=1:size(headers,2)-1
        pce_ts{i}.(headers{j})=data_mat(:,j);
    end
    

end

%% import population

filename = 'Table 2.6. Personal Income and Its Disposition, Monthly.csv';
% open file
fid = fopen(filename);
% read lines until data begins
while isempty(strfind(fgetl(fid),'Last Revised'))
    % do nothing
end
% get data
year_txt = textscan(fgetl(fid),'%s','Delimiter',',');
year_txt = cellstr(vertcat(year_txt{1}{3:end}));
month_txt = textscan(fgetl(fid),'%s','Delimiter',',');
month_txt = cellstr(vertcat(month_txt{1}{3:end}));

ncols = length(year_txt);
while isempty(strfind(fgetl(fid),'39,   '))
    
end
population = textscan(fgetl(fid),['%f' '%s' '%s' repmat('%f ',1,ncols)],'Delimiter',',','EmptyValue',NaN,'TreatAsEmpty','---');
fts_name = population(2:3);
population = population(4:end);
fclose(fid);

% put together in a struct
date = datenum(cell2mat([year_txt month_txt]),'yyyymmm');
population_ts.dates = date;
population_ts.population = cell2mat(population)';

%% construct real per capita consumption growth

% construct cons growth of nondurables and services 
% get pce price indexes
for i=1:length(pce_ts)
    if ~isempty(strfind(pce_ts{i}.desc,'Table 2.8.4'))
        price_pce_services = pce_ts{i}.Services;
        price_pce_nondur = pce_ts{i}.Nondurablegoods;
    end
end

% get nominal per capita pce
for i=1:length(pce_ts)
    if ~isempty(strfind(pce_ts{i}.desc,'Table 2.8.5'))
        pce_services = pce_ts{i}.Services./population_ts.population;
        pce_nondur = pce_ts{i}.Nondurablegoods./population_ts.population;
    end
end

real_pce_services = pce_services./price_pce_services;
real_pce_nondur = pce_nondur./price_pce_nondur;
real_pce =real_pce_services+real_pce_nondur;

% put together in a struct
cons_ts.dates = pce_ts{1}.dates(2:end);
cons_ts.dc = (real_pce(2:end)-real_pce(1:end-1))./real_pce(1:end-1);



%% Table 1: Descriptive statistics

% keep sample used for table 1 (sample used for rolling regressions of returns on inflation)
keep_table1 = inf_ts.dates>=date_begin & inf_ts.dates<=date_end;
inf_ts=structfun(@(x) x(keep_table1),inf_ts,'UniformOutput',false);
keep_table1 = cons_ts.dates>=date_begin & cons_ts.dates<=date_end;
cons_ts=structfun(@(x) x(keep_table1),cons_ts,'UniformOutput',false);
keep_table1 = ff_ts.dates>=date_begin & ff_ts.dates<=date_end;
ff_ts=structfun(@(x) x(keep_table1),ff_ts,'UniformOutput',false);

% compute summary stats
stats = [inf_ts.inf/100  inf_ts.u cons_ts.dc ff_ts.mktrf ff_ts.rf];
stats_headers = {'inflation','inflation shock','cons  growth','mkt_rf','rf'};
means = 12*100*mean(stats);
stddev = sqrt(12)*100 * std(stats);

for i = 1 : size(stats,2)
    beta = regress(stats(1:end-1,i),[ones(size(stats(1:end-1,i))) stats(2:end,i)]);
    ar(i) = beta(2);                             % AR(1) coefficients
end
corr_stats = corr(stats);                       % correlation matrix

%% Table 1
disp('Table 1: ');
disp('Mean: '); disp(cellfun(@(x) sprintf('%0.2f',x),num2cell(means),'UniformOutput',0))
disp('Std. dev.: '); disp(cellfun(@(x) sprintf('%0.2f',x),num2cell(stddev),'UniformOutput',0))
disp('AR(1): '); disp(cellfun(@(x) sprintf('%0.2f',100*x),num2cell(ar),'UniformOutput',0))
disp('Correlations: '); disp(cellfun(@(x) sprintf('%0.2f',100*x),num2cell(corr_stats),'UniformOutput',0))
