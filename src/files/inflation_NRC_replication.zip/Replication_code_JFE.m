%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Table 2: Unconditional and Conditional Predictive Regressions of Consumption Growth on Inflation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('data_replication_jfe.mat','dates','inflation','cg')

% inflation: growth rate in CPI (CPI(t)/CPI(t-1)-1) 
% cg: non-durables and services consumption growth

Tstart=393;% start of consumption data for estimation of nominal-real covariance
Tend=1063;
g=12; % predict 12 month compounded consumption growth
for t=Tstart:Tend-12+1
    cg(t,2)=prod(1+cg(t:t+12-1,1))-1;
end
period=60; % half-life
C=cg(Tstart:Tend,2);
I=inflation(Tstart-2:Tend-2,1); % lag inflation by additional month to account for reporting delay
for t=1:length(I)-period
    clear Kw
    h=log(2)/(period);
    ts=t+period-12+1;
    for tt=1:(ts-1)
        Kw(tt,1)=exp(-abs(ts-tt-1)*h);
    end
    Kw=Kw(:,1)/sum(Kw(:,1));
    NRC(t+period,1:2)=(lscov([ones(t+period-12,1) I(1:t+period-12,1)],C(1:t+period-12,1),Kw(1:end)))'; %betas from the predictive regression which you can combine with inflation (t) to predict ip (t+1)
end

% Unconditional predictive regression at horizon K=12 (column 4 of Table 2)
disp('Unconditional predictive regression at horizon K=12 (column 4 of Table 2)')
regress(C(end-569:end-11,1),[ones(570-11,1) I(end-569:end-11,1)])
% Conditional predictive regression at horizon K=12 (column 8 of Table 2)
disp('Conditional predictive regression at horizon K=12 (column 8 of Table 2)')
regress(C(end-569:end-11,1),[ones(570-11,1) NRC(end-569:end-11,1)+NRC(end-569:end-11,2).*I(end-569:end-11,1)])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Table 3: Characterizing Inflation Beta-Sorted Portfolios and the Inflation Risk Premium
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('data_replication_jfe.mat','retHL','inflation_arma')

% retHL: 10 portfolios sorted on inflation beta (from High to Low) and H-L
% inflation_arma: arma(1,1) innovation in inflation 

% Average return (Row 3 of Table 3)
disp('Average return (Row 3 of Table 3)')
mean(retHL)*1200

% Post-ranking inflation beta (Row 1 of Table 3)
T=length(retHL);
for i=1:11
    Beta_pi_post(:,i)=regress(retHL(:,i),[ones(T,1) inflation_arma]);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Table 5: Predicting the Inflation Risk Premium with the Nominal-Real Covariance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('data_replication_jfe.mat','RF')

% RF is the risk-free rate from Kenneth French's website

% Compound returns to annual horizon
H=12;
retHL12=NaN(size(retHL));
for t=1:T-12+1
    retHL12(t,1:10)=prod(1+retHL(t:t+12-1,1:10)+RF(t:t+12-1,ones(10,1)),1)-prod(1+RF(t:t+12-1,ones(10,1)),1);
end
retHL12(:,11)=retHL12(:,1)-retHL12(:,10);

% Predictive regression of returns on nominal-real covariance at annual
% horizon (Rows 15 and 18 of Table 5)
for i=1:11
    coefficientsT5(:,i)=(regress(retHL12(1:end-12+1,i)*100,[ones(570-12+1,1) (NRC(end-569:end-12+1,2)-mean(NRC(end-569:end-12+1,2)))/std(NRC(end-569:end-12+1,2))]))';
end
disp('Predictive regression of returns on nominal-real covariance at annual horizon (Rows 15 and 18 of Table 5)')
coefficientsT5

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Table 6: Time-Varying Inflation Risk Premia in Pooled Regressions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('data_replication_jfe.mat','retHL_long','inflation_arma_long') 

% retHL_long is retHL over overlapping sample (from 1967 July to December 2014), but includes an additional five years of data from 1962 July to 1967 June in
% order to estimate conditional inflation betas
% inflation_arma_long is inflation_arma over overlapping sample (from 1967 July to December 2014), but includes an additional five years of data from 1962 July to 1967 June in
% order to estimate conditional inflation betas

for i=1:10
    period=60;
    for t=1:length(retHL_long)-period
        clear Kw
        h=log(2)/(period);
        ts=t+period;
        for tt=1:(ts-1)
            Kw(tt,1)=exp(-abs(ts-tt-1)*h);
        end
        Kw=Kw(:,1)/sum(Kw(:,1));
        beta_pi_rolling(t,(i-1)*2+1:i*2)=(lscov([ones(t+period-1,1) inflation_arma_long(1:t+period-1,1)],retHL_long(1:t+period-1,i),Kw))';
    end
end

% Pooled regression of inflation beta-sorted portfolio returns on their
% conditional inflation beta (X{1}), the nominal-real covariance (X{2}) and
% their interaction at the annual horizon
X{1}=beta_pi_rolling(1:end-12+1,2:2:end)-mean(mean(beta_pi_rolling(1:end-12+1,2:2:end)));
X{2}=repmat((NRC(end-569:end-12+1,2)-mean(NRC(end-569:end-12+1,2)))/std(NRC(end-569:end-12+1,2)),1,10);
X{3}=repmat(mean(X{1}),570-12+1,1);
X{4}=repmat(mean(X{1},2),1,10);
[Ta,Tb]=size(X{1});
for i=1:4
    X{i}=reshape(X{i},Ta*Tb,1);
end

% column [2] of Table 6
disp('column [2] of Table 6')
regress(reshape(retHL12(1:end-12+1,1:10)*100,Ta*Tb,1),[ones(Ta*Tb,1) X{1} X{2} X{1}.*X{2}])
% column [3] of Table 6
disp('column [3] of Table 6')
regress(reshape(retHL12(1:end-12+1,1:10)*100,Ta*Tb,1),[ones(Ta*Tb,1) X{1} X{2} X{3}.*X{2}])
% column [4] of Table 6
disp('column [4] of Table 6')
regress(reshape(retHL12(1:end-12+1,1:10)*100,Ta*Tb,1),[ones(Ta*Tb,1) X{1} X{2} X{4}.*X{2}])
% column [5] of Table 6
disp('column [5] of Table 6')
regress(reshape(retHL12(1:end-12+1,1:10)*100,Ta*Tb,1),[ones(Ta*Tb,1) X{1} X{2} X{3}.*X{2} X{4}.*X{2}])

